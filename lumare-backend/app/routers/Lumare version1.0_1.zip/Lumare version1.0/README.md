# Lumare — version 1.0

Everything built so far for the Lumare skincare D2C project.

## What's in here

- **frontend/index.html** — Single-file storefront. Ikigai-inspired pastel design
  (concentric ring hero, floating photo accents), real product photography embedded
  directly in the file, full cart + checkout wired to the backend below (Razorpay
  test-mode checkout or Cash on Delivery), trust badges, ingredient ticker, FAQ-style
  "Why Lumare" section, and a full footer.

- **lumare-backend/** — FastAPI + PostgreSQL backend. Auth, product catalog, orders,
  Razorpay payments (test keys already in `.env`), Shiprocket shipping integration
  (code is real, waiting on your credentials), Zoho Books invoicing integration (code
  is real, waiting on your OAuth setup), and `admin/index.html`, a small internal
  dashboard for orders/inventory/shipments. Full setup instructions in
  `lumare-backend/README.md`.

## How to run this locally

```bash
cd lumare-backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Edit .env — DATABASE_URL needs a real Postgres instance (local or Railway's)
python -m app.seed               # creates the 3 products + admin user
uvicorn app.main:app --reload --port 8000
```

Then serve the frontend over a local server (not double-clicked — CORS needs a real
origin): `cd frontend && python -m http.server 5500`, then open
`http://localhost:5500` in your browser.

## Status at a glance

| Piece | Status |
|---|---|
| Frontend | Built, wired to backend, real photos + logo embedded |
| Backend (FastAPI + Postgres) | Built: auth, products, orders, admin |
| Razorpay | Test keys installed in `.env`, not yet live-tested |
| Shiprocket | Real integration code, waiting on your credentials |
| Zoho Books | Real integration code, needs your OAuth self-client setup |
| Admin dashboard | Built, functional against the backend |
| GitHub | In progress — pushing via GitHub Desktop |
| Railway deployment | Blocked on GitHub push completing first |

## Deploying to Railway (once pushed to GitHub)

Full step-by-step is in `lumare-backend/README.md` — short version: new Railway
project → add a PostgreSQL plugin → add a service from your GitHub repo with root
directory `lumare-backend` and start command
`uvicorn app.main:app --host 0.0.0.0 --port $PORT` → copy every variable from your
local `.env` into Railway's Variables tab → run `python -m app.seed` once via
Railway's Shell feature → generate a public domain.
