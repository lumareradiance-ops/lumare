import time

import httpx

from app.config import settings

ZOHO_ACCOUNTS_BASE = "https://accounts.zoho.in/oauth/v2/token"
ZOHO_BOOKS_BASE = "https://www.zohoapis.in/books/v3"

_token_cache = {"token": None, "expires_at": 0}


def get_access_token() -> str:
    """
    Zoho uses a long-lived refresh token (generated once via the self-client flow in
    the Zoho API console) to mint short-lived access tokens on demand.
    """
    now = time.time()
    if _token_cache["token"] and now < _token_cache["expires_at"]:
        return _token_cache["token"]

    if not all([settings.zoho_client_id, settings.zoho_client_secret, settings.zoho_refresh_token]):
        raise RuntimeError(
            "Zoho credentials are not set. Add ZOHO_CLIENT_ID, ZOHO_CLIENT_SECRET, "
            "and ZOHO_REFRESH_TOKEN to your .env — generate these once in the Zoho API console."
        )

    resp = httpx.post(
        ZOHO_ACCOUNTS_BASE,
        params={
            "refresh_token": settings.zoho_refresh_token,
            "client_id": settings.zoho_client_id,
            "client_secret": settings.zoho_client_secret,
            "grant_type": "refresh_token",
        },
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()
    _token_cache["token"] = data["access_token"]
    _token_cache["expires_at"] = now + data.get("expires_in", 3600) - 60
    return data["access_token"]


def create_invoice(order, items) -> dict:
    """
    Creates a draft invoice in Zoho Books for a paid order. Zoho auto-calculates GST
    based on the organization's tax settings — configure those in the Zoho Books UI first.
    """
    headers = {
        "Authorization": f"Zoho-oauthtoken {get_access_token()}",
        "Content-Type": "application/json",
    }
    payload = {
        "customer_name": order.customer_name,
        "email": order.customer_email,
        "line_items": [
            {
                "name": item.product_name,
                "rate": item.unit_price_inr,
                "quantity": item.quantity,
            }
            for item in items
        ],
    }
    resp = httpx.post(
        f"{ZOHO_BOOKS_BASE}/invoices",
        params={"organization_id": settings.zoho_organization_id},
        json=payload,
        headers=headers,
        timeout=20,
    )
    resp.raise_for_status()
    return resp.json()
